*********************************************************************
 THESE INSTRUCTIONS ARE ONLY FOR MAC OS X 10.3, AND WILL ONLY CREATE 
 STANDALONE BUNDLES FOR MAC OS X 10.3.  THERE IS NO SUPPORT FOR 
 MAC OS X 10.2.

Also works on 10.4 and 10.5
*********************************************************************


Install py2app and its dependencies.

easy_install py2app



To create the bundle:
    python setup.py py2app
